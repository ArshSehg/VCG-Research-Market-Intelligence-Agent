import { describe, it, expect, vi, beforeEach } from "vitest";
import type { UISource } from "@/types/data";

const searchMock = vi.hoisted(() => vi.fn());
vi.mock("exa-js", () => ({
  default: class {
    search = searchMock;
  },
}));

import { createWebSearch } from "@/app/api/chat/tools/web-search";
import { SOURCE_TRUST_GATE_QUESTION } from "@/lib/source-trust";

type Exec = (input: { query: string }, opts: unknown) => Promise<string>;
const run = (t: ReturnType<typeof createWebSearch>, query = "india cold chain market size") =>
  (t.execute as unknown as Exec)({ query }, { toolCallId: "t1", messages: [] });

const exaResponse = {
  results: [
    { url: "https://www.reddit.com/r/india/comments/1", title: "Reddit thread", text: "someone says CAGR is 30%" },
    { url: "https://blog.example/cold-chain", title: "A blog", text: "blog text" },
    { url: "https://www.reuters.com/markets/cold-chain", title: "Reuters piece", text: "reuters text", publishedDate: "2026-01-10" },
    { url: "https://nhb.gov.in/report", title: "NHB report", text: "official text" },
  ],
  output: { content: "SYNTHESIS that might blend in reddit claims", grounding: [] },
};

beforeEach(() => {
  searchMock.mockReset();
  searchMock.mockResolvedValue(exaResponse);
});

describe("webSearch source-trust gate", () => {
  it("refuses to search until a level is stated, and returns the gate question verbatim", async () => {
    const collected: UISource[] = [];
    const out = await run(createWebSearch((s) => collected.push(s), { sourceTrust: null }));
    expect(searchMock).not.toHaveBeenCalled();
    expect(collected).toHaveLength(0);
    expect(out).toContain("SOURCE TRUST GATE");
    expect(out).toContain(SOURCE_TRUST_GATE_QUESTION);
  });
});

describe("webSearch policy application", () => {
  it("STRICT: withholds Tier 4, orders Tier 1 first, drops the synthesis, labels tiers", async () => {
    const collected: UISource[] = [];
    const out = await run(createWebSearch((s) => collected.push(s), { sourceTrust: "STRICT" }));

    expect(out).toContain("Source policy in force: STRICT");
    // reddit withheld, not citable, not collected
    expect(out).not.toContain("# Web Source 4");
    expect(out).toMatch(/Withheld by STRICT source policy/);
    expect(out).toContain("reddit.com");
    expect(collected.map((s) => s.url)).not.toContain("https://www.reddit.com/r/india/comments/1");
    // synthesis dropped because something was withheld
    expect(out).not.toContain("SYNTHESIS that might blend");
    // best tier first: NHB (T1), Reuters (T2), blog (T3 unclassified)
    expect(collected.map((s) => s.tier)).toEqual([1, 2, 3]);
    expect(collected[0].url).toBe("https://nhb.gov.in/report");
    // labels present and flagged as heuristic
    expect(out).toMatch(/Source Tier \(domain-based heuristic, not a verification\)/);
    expect(out).toMatch(/\[unclassified\]/);
    expect(out).toContain("PRIMARY EVIDENCE");
  });

  it("BROAD: keeps Tier 4 but labels it discovery-only; keeps the synthesis", async () => {
    const collected: UISource[] = [];
    const out = await run(createWebSearch((s) => collected.push(s), { sourceTrust: "BROAD" }));

    expect(out).toContain("Source policy in force: BROAD");
    expect(out).not.toMatch(/Withheld by/);
    expect(collected).toHaveLength(4);
    const reddit = collected.find((s) => s.url.includes("reddit.com"))!;
    expect(reddit.tier).toBe(4);
    expect(out).toContain("DISCOVERY ONLY");
    expect(out).toContain("SYNTHESIS that might blend");
  });

  it("returns the search failure message without throwing", async () => {
    searchMock.mockRejectedValue(new Error("exa down"));
    const out = await run(createWebSearch(() => {}, { sourceTrust: "STANDARD" }));
    expect(out).toMatch(/temporarily unavailable/);
  });
});
