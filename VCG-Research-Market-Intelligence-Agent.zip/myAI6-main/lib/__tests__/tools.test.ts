import { describe, it, expect, vi } from "vitest";

const searchMock = vi.hoisted(() => vi.fn());
vi.mock("exa-js", () => ({
  default: class {
    search = searchMock;
  },
}));

import { buildToolSet } from "@/lib/ai/tools";
import { SOURCE_TRUST_GATE_QUESTION } from "@/lib/source-trust";

type Exec = (input: { query: string }, opts: unknown) => Promise<string>;
const runWebSearch = (tools: ReturnType<typeof buildToolSet>) =>
  (tools.webSearch!.execute as unknown as Exec)({ query: "q" }, { toolCallId: "t", messages: [] });

describe("buildToolSet wiring", () => {
  it("passes a missing source-trust level through, so webSearch refuses to search", async () => {
    searchMock.mockClear();
    const out = await runWebSearch(buildToolSet(() => {}, { sourceTrust: null }));
    expect(searchMock).not.toHaveBeenCalled();
    expect(out).toContain(SOURCE_TRUST_GATE_QUESTION);
  });

  it("defaults to the gate (no level) when no context is given", async () => {
    searchMock.mockClear();
    const out = await runWebSearch(buildToolSet(() => {}));
    expect(searchMock).not.toHaveBeenCalled();
    expect(out).toContain("SOURCE TRUST GATE");
  });

  it("passes a confirmed level through, so webSearch runs under that policy", async () => {
    searchMock.mockReset();
    searchMock.mockResolvedValue({ results: [], output: undefined });
    const out = await runWebSearch(buildToolSet(() => {}, { sourceTrust: "STRICT" }));
    expect(searchMock).toHaveBeenCalledTimes(1);
    expect(out).toContain("Source policy in force: STRICT");
  });

  it("does not register fetchOwnerProfiles when no owner profiles are configured", () => {
    expect(Object.keys(buildToolSet())).not.toContain("fetchOwnerProfiles");
  });
});
