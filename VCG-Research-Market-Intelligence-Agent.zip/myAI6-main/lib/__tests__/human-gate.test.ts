import { describe, it, expect } from "vitest";
import {
  hasHumanGate,
  humanGateSubmissionSchema,
  formatDecisionMessage,
} from "@/lib/human-gate";

const PACK_END = `# IMPLICATIONS

Something.

# HUMAN GATE

Status:
PENDING ENGAGEMENT MANAGER REVIEW

Decision:
APPROVE / CHALLENGE / REJECT`;

describe("hasHumanGate", () => {
  it("detects the block the master prompt prescribes", () => {
    expect(hasHumanGate(PACK_END)).toBe(true);
    expect(hasHumanGate(PACK_END.replace("# HUMAN GATE", "## Human Gate"))).toBe(true);
  });
  it("requires both the heading and the pending status", () => {
    expect(hasHumanGate("# HUMAN GATE\n\nsomething else")).toBe(false);
    expect(hasHumanGate("PENDING ENGAGEMENT MANAGER REVIEW")).toBe(false);
  });
  it("does not trigger on a passing mention", () => {
    expect(hasHumanGate("The human gate step is described above. PENDING ENGAGEMENT MANAGER REVIEW")).toBe(false);
  });
  it("is false for ordinary answers", () => {
    expect(hasHumanGate("India's cold chain market is growing.")).toBe(false);
  });
});

describe("humanGateSubmissionSchema", () => {
  const base = { messageId: "m1", conversationId: "c1" };
  it("APPROVE needs no reason", () => {
    expect(humanGateSubmissionSchema.safeParse({ ...base, decision: "APPROVE" }).success).toBe(true);
  });
  it("CHALLENGE and REJECT require a real reason", () => {
    for (const decision of ["CHALLENGE", "REJECT"]) {
      expect(humanGateSubmissionSchema.safeParse({ ...base, decision }).success).toBe(false);
      expect(humanGateSubmissionSchema.safeParse({ ...base, decision, reason: "  no " }).success).toBe(false);
      expect(
        humanGateSubmissionSchema.safeParse({ ...base, decision, reason: "Market size CAGR conflicts with the NHB figure" }).success
      ).toBe(true);
    }
  });
  it("rejects unknown decisions and oversized reasons", () => {
    expect(humanGateSubmissionSchema.safeParse({ ...base, decision: "MAYBE" }).success).toBe(false);
    expect(
      humanGateSubmissionSchema.safeParse({ ...base, decision: "REJECT", reason: "x".repeat(2001) }).success
    ).toBe(false);
  });
});

describe("formatDecisionMessage", () => {
  it("produces the protocol prefix the system prompt keys on", () => {
    const m = formatDecisionMessage("CHALLENGE", " Revisit the margin benchmark ", "A. Sehgal");
    expect(m.startsWith("HUMAN GATE DECISION: CHALLENGE")).toBe(true);
    expect(m).toContain("Reviewer: A. Sehgal");
    expect(m).toContain("Reason: Revisit the margin benchmark");
  });
  it("omits the reviewer line when none is given", () => {
    expect(formatDecisionMessage("REJECT", "Unsupported claims")).not.toContain("Reviewer:");
  });
});
