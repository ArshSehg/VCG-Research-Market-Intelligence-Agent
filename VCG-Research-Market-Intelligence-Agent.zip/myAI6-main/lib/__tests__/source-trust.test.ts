import { describe, it, expect } from "vitest";
import type { UIMessage } from "ai";
import {
  detectSourceTrust,
  classifySource,
  applySourcePolicy,
  SOURCE_TRUST_GATE_QUESTION,
  sourceTrustGateToolMessage,
} from "@/lib/source-trust";
import { VCG_MASTER_PROMPT } from "@/vcg/master-prompt";

const user = (text: string, id = Math.random().toString()): UIMessage => ({
  id,
  role: "user",
  parts: [{ type: "text", text }],
});
const assistant = (text: string, id = Math.random().toString()): UIMessage => ({
  id,
  role: "assistant",
  parts: [{ type: "text", text }],
});

describe("detectSourceTrust", () => {
  it("returns null when nothing has been stated", () => {
    expect(detectSourceTrust([user("Assess Indian cold-chain logistics margins")])).toBeNull();
    expect(detectSourceTrust([])).toBeNull();
  });

  it("does not trigger on ordinary uses of the words", () => {
    expect(detectSourceTrust([user("What is the standard deviation of margins across a broad set of players?")])).toBeNull();
    expect(detectSourceTrust([user("Give me a strict timeline for the study")])).toBeNull();
  });

  it("detects an explicit statement inside the brief", () => {
    expect(detectSourceTrust([user("Source trust level: STRICT. Assess cold chain.")])).toBe("STRICT");
    expect(detectSourceTrust([user("Please use the standard source policy for this")])).toBe("STANDARD");
    expect(detectSourceTrust([user("go with broad sources, I need coverage")])).toBe("BROAD");
    expect(detectSourceTrust([user("source-trust = broad")])).toBe("BROAD");
  });

  it("reads a reply to the gate question (word or number)", () => {
    const gate = assistant(SOURCE_TRUST_GATE_QUESTION);
    expect(detectSourceTrust([user("brief"), gate, user("Standard please")])).toBe("STANDARD");
    expect(detectSourceTrust([user("brief"), gate, user("1")])).toBe("STRICT");
    expect(detectSourceTrust([user("brief"), gate, user("option 3")])).toBe("BROAD");
    expect(detectSourceTrust([user("brief"), gate, user("2.")])).toBe("STANDARD");
  });

  it("rejects ambiguous gate replies instead of guessing", () => {
    const gate = assistant(SOURCE_TRUST_GATE_QUESTION);
    expect(detectSourceTrust([user("brief"), gate, user("1. STRICT 2. STANDARD 3. BROAD")])).toBeNull();
    expect(detectSourceTrust([user("brief"), gate, user("what's the difference?")])).toBeNull();
  });

  it("does not read bare numbers or words as a choice when the gate was not asked", () => {
    expect(detectSourceTrust([user("brief"), assistant("Here is the plan."), user("2")])).toBeNull();
    expect(detectSourceTrust([user("brief"), assistant("Here is the plan."), user("Strict")])).toBeNull();
  });

  it("the most recent statement wins", () => {
    const gate = assistant(SOURCE_TRUST_GATE_QUESTION);
    const msgs = [user("brief"), gate, user("strict"), assistant("ok"), user("Actually, use the broad source policy")];
    expect(detectSourceTrust(msgs)).toBe("BROAD");
  });

  it("the gate wording in the tool/helper matches the master prompt verbatim", () => {
    expect(VCG_MASTER_PROMPT).toContain(SOURCE_TRUST_GATE_QUESTION);
    expect(sourceTrustGateToolMessage()).toContain(SOURCE_TRUST_GATE_QUESTION);
  });
});

describe("classifySource (heuristic tiers)", () => {
  const tier = (u: string) => classifySource(u).tier;

  it("Tier 1: government, regulators, official institutions", () => {
    expect(tier("https://www.sebi.gov.in/reports/x.html")).toBe(1);
    expect(tier("https://rbi.org.in/Scripts/AnnualReportPublications.aspx")).toBe(1);
    expect(tier("https://www.sec.gov/Archives/edgar/data/1")).toBe(1);
    expect(tier("https://data.worldbank.org/indicator/NY.GDP.MKTP.CD")).toBe(1);
    expect(classifySource("https://www.sebi.gov.in/x").recommendedUse).toBe("PRIMARY EVIDENCE");
  });

  it("Tier 1: company investor-relations disclosures", () => {
    expect(tier("https://investors.examplecorp.com/results")).toBe(1);
    expect(tier("https://www.examplecorp.com/downloads/annual-report-2025.pdf")).toBe(1);
  });

  it("a known press/research domain is not promoted to Tier 1 by an annual-report URL path", () => {
    expect(tier("https://www.reuters.com/business/acme-annual-report-2025/")).toBe(2);
    expect(tier("https://www.grandviewresearch.com/press/annual-report-market")).toBe(3);
  });

  it("Tier 2: academic, research orgs, industry bodies, established press", () => {
    expect(tier("https://www.iima.ac.in/paper")).toBe(2);
    expect(tier("https://www.mckinsey.com/industries/x")).toBe(2);
    expect(tier("https://www.reuters.com/markets/x")).toBe(2);
    expect(tier("https://www.ibef.org/industry/logistics")).toBe(2);
  });

  it("Tier 3: specialist sources and unknown domains (flagged unclassified)", () => {
    const known = classifySource("https://www.grandviewresearch.com/industry-analysis/x");
    expect(known.tier).toBe(3);
    expect(known.classified).toBe(true);
    expect(known.recommendedUse).toBe("CONTEXT ONLY");

    const unknown = classifySource("https://random-logistics-blog.example/post");
    expect(unknown.tier).toBe(3);
    expect(unknown.classified).toBe(false);
  });

  it("Tier 4: forums, social, user-generated, wikis", () => {
    expect(tier("https://www.reddit.com/r/india/comments/abc")).toBe(4);
    expect(tier("https://en.wikipedia.org/wiki/Cold_chain")).toBe(4);
    expect(tier("https://someone.substack.com/p/x")).toBe(4);
    expect(classifySource("https://www.quora.com/q").recommendedUse).toBe("DISCOVERY ONLY");
  });

  it("a low-trust platform stays Tier 4 even if the path looks official", () => {
    expect(tier("https://www.linkedin.com/company/x/annual-report")).toBe(4);
  });

  it("matches on hostname boundaries, not substrings", () => {
    // 'notreddit.com' must not be treated as reddit.com; 'fakegov.in' is not a .gov.in site
    expect(classifySource("https://notreddit.com/x").tier).toBe(3);
    expect(classifySource("https://fakegov.in/x").tier).toBe(3);
  });

  it("unparseable URLs are discovery-only, unclassified", () => {
    const c = classifySource("not a url");
    expect(c.tier).toBe(4);
    expect(c.classified).toBe(false);
  });

  it("every assessment says heuristic / unverified in its reason", () => {
    for (const u of [
      "https://www.sebi.gov.in/x",
      "https://www.reuters.com/x",
      "https://www.reddit.com/x",
      "https://unknown.example/x",
    ]) {
      expect(classifySource(u).reason).toMatch(/heuristic|not verified|unknown/i);
    }
  });
});

describe("applySourcePolicy", () => {
  const items = [
    { url: "https://blog.example/a", tier: classifySource("https://blog.example/a") }, // T3 unclassified
    { url: "https://www.reddit.com/r/x", tier: classifySource("https://www.reddit.com/r/x") }, // T4
    { url: "https://www.reuters.com/a", tier: classifySource("https://www.reuters.com/a") }, // T2
    { url: "https://www.sebi.gov.in/a", tier: classifySource("https://www.sebi.gov.in/a") }, // T1
  ];

  it.each(["STRICT", "STANDARD"] as const)("%s withholds explicit Tier 4 and orders best tier first", (level) => {
    const { kept, withheld } = applySourcePolicy(items, level);
    expect(withheld.map((r) => r.url)).toEqual(["https://www.reddit.com/r/x"]);
    expect(kept.map((r) => r.tier.tier)).toEqual([1, 2, 3]);
  });

  it("BROAD keeps everything in the original order (labels do the work)", () => {
    const { kept, withheld } = applySourcePolicy(items, "BROAD");
    expect(withheld).toEqual([]);
    expect(kept.map((r) => r.url)).toEqual(items.map((r) => r.url));
  });

  it("sorting is stable within a tier", () => {
    const a = { url: "https://www.reuters.com/1", tier: classifySource("https://www.reuters.com/1") };
    const b = { url: "https://www.livemint.com/2", tier: classifySource("https://www.livemint.com/2") };
    expect(applySourcePolicy([a, b], "STANDARD").kept.map((r) => r.url)).toEqual([a.url, b.url]);
  });

  it("does not withhold unclassified (unknown) domains", () => {
    const unknown = { url: "https://x.example", tier: classifySource("https://x.example") };
    expect(applySourcePolicy([unknown], "STRICT").kept).toHaveLength(1);
  });
});
