// lib/human-gate.ts
//
// Human Gate (VCG master prompt sections 24-25): the Engagement Manager
// approves, challenges or rejects a research pack, and the decision and reason
// are retained. Shared by the API route, the UI card and tests.

import { z } from "zod";

export const HUMAN_GATE_DECISIONS = ["APPROVE", "CHALLENGE", "REJECT"] as const;
export type HumanGateDecision = (typeof HUMAN_GATE_DECISIONS)[number];

export const MIN_REASON_CHARS = 5;
export const MAX_REASON_CHARS = 2000;

export const humanGateSubmissionSchema = z
  .object({
    messageId: z.string().min(1).max(200),
    conversationId: z.string().min(1).max(200).optional(),
    decision: z.enum(HUMAN_GATE_DECISIONS),
    reason: z.string().max(MAX_REASON_CHARS).optional(),
    reviewer: z.string().max(120).optional(),
  })
  .refine(
    (d) => d.decision === "APPROVE" || (d.reason?.trim().length ?? 0) >= MIN_REASON_CHARS,
    {
      message: `A reason of at least ${MIN_REASON_CHARS} characters is required to challenge or reject.`,
      path: ["reason"],
    }
  );
export type HumanGateSubmission = z.infer<typeof humanGateSubmissionSchema>;

/** A decision as retained client-side (adds the time it was made). */
export type StoredHumanGateDecision = {
  decision: HumanGateDecision;
  reason?: string;
  reviewer?: string;
  decidedAt: string; // ISO 8601
};

/**
 * True when an assistant message ends a research pack with the HUMAN GATE
 * block the master prompt prescribes (section 34): a "HUMAN GATE" heading and
 * the pending-review status line.
 */
export function hasHumanGate(text: string): boolean {
  return (
    /^[ \t]{0,3}#{1,6}[ \t]*HUMAN GATE\b/im.test(text) &&
    /PENDING ENGAGEMENT MANAGER REVIEW/i.test(text)
  );
}

/**
 * The chat message sent to the agent for CHALLENGE / REJECT. The prefix is the
 * protocol the system prompt keys on ("HUMAN GATE DECISION: ...").
 */
export function formatDecisionMessage(
  decision: Exclude<HumanGateDecision, "APPROVE">,
  reason: string,
  reviewer?: string
): string {
  const lines = [`HUMAN GATE DECISION: ${decision}`];
  if (reviewer?.trim()) lines.push(`Reviewer: ${reviewer.trim()}`);
  lines.push(`Reason: ${reason.trim()}`);
  return lines.join("\n");
}
