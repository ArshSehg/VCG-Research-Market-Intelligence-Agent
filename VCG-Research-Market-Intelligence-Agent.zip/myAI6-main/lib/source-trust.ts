// lib/source-trust.ts
//
// Source Trust Gate + Source Hierarchy (VCG master prompt sections 6-8).
//
// Three responsibilities, all deterministic (no LLM involved):
//   1. detectSourceTrust(): has the consultant chosen STRICT / STANDARD / BROAD?
//   2. classifySource(): heuristic Tier 1-4 label for a URL (domain-based).
//   3. applySourcePolicy(): withhold / order web results according to the level.
//
// The tier labels are HEURISTICS. A domain cannot establish provenance,
// methodology or independence — the model and the consultant still make the
// real assessment (master prompt s.8). Everything here says "heuristic" so no
// downstream text presents a domain match as verification.

import type { UIMessage } from "ai";
import {
  SOURCE_TIER1_SUFFIXES,
  SOURCE_TIER1_DOMAINS,
  SOURCE_TIER1_HOST_PREFIXES,
  SOURCE_TIER1_PATH_PATTERN,
  SOURCE_TIER2_SUFFIXES,
  SOURCE_TIER2_DOMAINS,
  SOURCE_TIER3_DOMAINS,
  SOURCE_TIER4_DOMAINS,
} from "@/config";

export type SourceTrustLevel = "STRICT" | "STANDARD" | "BROAD";
export type SourceTier = 1 | 2 | 3 | 4;

export const SOURCE_TRUST_LEVELS: readonly SourceTrustLevel[] = ["STRICT", "STANDARD", "BROAD"];

// Verbatim from master prompt s.6 (kept identical so the consultant always
// sees the same wording, whether the model or the tool gate asks).
export const SOURCE_TRUST_GATE_QUESTION = `Before I begin, what source-trust level should I use?

1. STRICT
Primary sources are preferred and should be used wherever reasonably available. Secondary sources are mainly used for triangulation and context.

2. STANDARD
Primary sources are prioritized, with credible secondary sources used where primary evidence is unavailable or insufficient.

3. BROAD
Use primary, secondary and specialist industry sources to maximize research coverage, while clearly labelling source quality.

For client-facing or high-stakes work, STRICT or STANDARD is recommended.`;

// ---------------------------------------------------------------------------
// 1. Detecting the consultant's choice
// ---------------------------------------------------------------------------

const LEVEL_WORD = "(strict|standard|broad)";

// Patterns that are explicit enough to trust anywhere in a user message.
const EXPLICIT_PATTERNS: RegExp[] = [
  // "source trust level: STRICT", "source-trust = standard", "source policy is broad"
  new RegExp(
    `source[- ]?(?:trust|policy|standard)(?:[- ]?(?:level|policy))?\\s*(?:is|=|:|-|to|as)?\\s*[*_"']*\\s*${LEVEL_WORD}\\b`,
    "i"
  ),
  // "use the strict source policy", "go with standard sources", "choose broad trust"
  new RegExp(
    `\\b(?:use|using|go(?:ing)?\\s+with|choose|chose|chosen|select(?:ed)?|pick(?:ed)?|set|apply)\\s+(?:the\\s+)?${LEVEL_WORD}\\s+(?:source|sources|trust|policy|mode|level|standard)\\b`,
    "i"
  ),
  // "strict source-trust", "standard trust level"
  new RegExp(`\\b${LEVEL_WORD}\\s+(?:source[- ]?trust|source\\s+policy|trust\\s+level|trust\\s+policy)\\b`, "i"),
];

function messageText(m: UIMessage): string {
  return (m.parts ?? [])
    .filter((p) => p.type === "text")
    .map((p) => ("text" in p ? (p as { text: string }).text : ""))
    .join("\n");
}

/** Did this assistant message ask the source-trust gate question? */
function askedGate(text: string): boolean {
  return /source[- ]trust level/i.test(text) && /STRICT/.test(text) && /BROAD/.test(text);
}

function toLevel(word: string): SourceTrustLevel {
  return word.toUpperCase() as SourceTrustLevel;
}

/**
 * Reply to a gate question: accept "2", "option 2", "Standard please", "go with
 * STRICT". Ambiguous replies (several different level words, e.g. the consultant
 * pasting the whole list back) are rejected rather than guessed.
 */
function parseGateReply(text: string): SourceTrustLevel | null {
  const trimmed = text.trim();
  const words = new Set((trimmed.match(/\b(strict|standard|broad)\b/gi) ?? []).map((w) => w.toLowerCase()));
  if (words.size === 1) return toLevel([...words][0]);
  if (words.size > 1) return null;
  if (trimmed.length <= 30) {
    const m = trimmed.match(/^\W*(?:option\s*|number\s*|#)?([123])\b/i);
    if (m) return SOURCE_TRUST_LEVELS[Number(m[1]) - 1];
  }
  return null;
}

/**
 * Returns the source-trust level the consultant has stated for this
 * conversation, or null if none. The most recent statement wins (the
 * consultant may change it; the AI must never change it silently).
 */
export function detectSourceTrust(messages: UIMessage[]): SourceTrustLevel | null {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role !== "user") continue;
    const text = messageText(m);
    if (!text) continue;

    const prev = i > 0 ? messages[i - 1] : undefined;
    if (prev?.role === "assistant" && askedGate(messageText(prev))) {
      const reply = parseGateReply(text);
      if (reply) return reply;
    }

    for (const re of EXPLICIT_PATTERNS) {
      const match = text.match(re);
      if (match) return toLevel(match[1]);
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// 2. Tier classification (heuristic)
// ---------------------------------------------------------------------------

export interface TierAssessment {
  tier: SourceTier;
  /** false when the domain matched no list and the default (Tier 3) was applied. */
  classified: boolean;
  /** Why this tier was assigned (always heuristic). */
  reason: string;
  /** Master-prompt s.8 vocabulary: how the source may be used by default. */
  recommendedUse: "PRIMARY EVIDENCE" | "SUPPORTING EVIDENCE" | "CONTEXT ONLY" | "DISCOVERY ONLY";
}

const TIER_LABEL: Record<SourceTier, string> = {
  1: "Tier 1 - Primary / direct evidence",
  2: "Tier 2 - High-quality secondary evidence",
  3: "Tier 3 - Specialist / supporting source",
  4: "Tier 4 - Discovery / low-trust source",
};

export function tierLabel(tier: SourceTier): string {
  return TIER_LABEL[tier];
}

function normalizeHost(url: string): string {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return "";
  }
}

function hostMatches(host: string, domains: readonly string[]): string | undefined {
  return domains.find((d) => host === d || host.endsWith("." + d));
}

function suffixMatches(host: string, suffixes: readonly string[]): string | undefined {
  return suffixes.find((s) => host.endsWith(s));
}

export function classifySource(url: string): TierAssessment {
  const host = normalizeHost(url);
  if (!host) {
    return {
      tier: 4,
      classified: false,
      reason: "URL could not be parsed; provenance unknown (heuristic)",
      recommendedUse: "DISCOVERY ONLY",
    };
  }

  // Tier 4 first: a low-trust platform stays low-trust even if a path looks official.
  const t4 = hostMatches(host, SOURCE_TIER4_DOMAINS);
  if (t4) {
    return {
      tier: 4,
      classified: true,
      reason: `${t4} is a forum / social / user-generated / aggregator domain (heuristic)`,
      recommendedUse: "DISCOVERY ONLY",
    };
  }

  const t1domain = hostMatches(host, SOURCE_TIER1_DOMAINS);
  const t1suffix = suffixMatches(host, SOURCE_TIER1_SUFFIXES);
  if (t1domain || t1suffix) {
    return {
      tier: 1,
      classified: true,
      reason: `government / regulator / official institution domain (${t1domain ?? t1suffix}) (heuristic; confirm it is the original publication)`,
      recommendedUse: "PRIMARY EVIDENCE",
    };
  }

  let path = "";
  try {
    path = new URL(url).pathname;
  } catch {
    /* host already validated above */
  }
  // The IR / annual-report heuristic only applies to domains we do NOT already
  // know to be press, research or specialist publishers: a Reuters or Mint
  // article about a company's annual report is not that company's own filing.
  const knownPublisher =
    hostMatches(host, SOURCE_TIER2_DOMAINS) ||
    suffixMatches(host, SOURCE_TIER2_SUFFIXES) ||
    hostMatches(host, SOURCE_TIER3_DOMAINS);
  const irHost = SOURCE_TIER1_HOST_PREFIXES.find((p) => host.startsWith(p));
  if (!knownPublisher && (irHost || new RegExp(SOURCE_TIER1_PATH_PATTERN, "i").test(path))) {
    return {
      tier: 1,
      classified: true,
      reason: "looks like a company investor-relations / annual-report disclosure (heuristic; confirm it is the company's own filing)",
      recommendedUse: "PRIMARY EVIDENCE",
    };
  }

  const t2domain = hostMatches(host, SOURCE_TIER2_DOMAINS);
  const t2suffix = suffixMatches(host, SOURCE_TIER2_SUFFIXES);
  if (t2domain || t2suffix) {
    return {
      tier: 2,
      classified: true,
      reason: `academic / research institution / industry body / established publication (${t2domain ?? t2suffix}) (heuristic)`,
      recommendedUse: "SUPPORTING EVIDENCE",
    };
  }

  const t3 = hostMatches(host, SOURCE_TIER3_DOMAINS);
  if (t3) {
    return {
      tier: 3,
      classified: true,
      reason: `${t3} is a trade / specialist / market-research source; methodology may be opaque - corroborate (heuristic)`,
      recommendedUse: "CONTEXT ONLY",
    };
  }

  return {
    tier: 3,
    classified: false,
    reason: "domain not in any tier list; provenance not verified (treated as Tier 3, unclassified)",
    recommendedUse: "CONTEXT ONLY",
  };
}

// ---------------------------------------------------------------------------
// 3. Policy application
// ---------------------------------------------------------------------------

export interface PolicyResult<T> {
  kept: T[];
  /** Results removed by policy (always explicit Tier 4 under STRICT/STANDARD). */
  withheld: T[];
}

/**
 * STRICT / STANDARD: withhold explicit Tier 4 (discovery-only) domains and
 * order what remains best-tier-first (stable, so relevance order is preserved
 * within a tier). BROAD: keep everything in the engine's order; the tier label
 * does the work.
 */
export function applySourcePolicy<T extends { tier: TierAssessment }>(
  items: T[],
  level: SourceTrustLevel
): PolicyResult<T> {
  if (level === "BROAD") return { kept: items, withheld: [] };

  const withheld = items.filter((r) => r.tier.tier === 4 && r.tier.classified);
  const kept = items
    .map((r, idx) => ({ r, idx }))
    .filter(({ r }) => !(r.tier.tier === 4 && r.tier.classified))
    .sort((a, b) => a.r.tier.tier - b.r.tier.tier || a.idx - b.idx)
    .map(({ r }) => r);
  return { kept, withheld };
}

// ---------------------------------------------------------------------------
// Prompt / tool text
// ---------------------------------------------------------------------------

export const SOURCE_POLICY_DESCRIPTION: Record<SourceTrustLevel, string> = {
  STRICT:
    "Use Tier 1 (primary) sources for every material claim wherever reasonably available. Tier 2 and Tier 3 sources are for triangulation and context only and must be labelled that way. Tier 4 sources are withheld by the search tool.",
  STANDARD:
    "Prioritise Tier 1 sources. Use credible Tier 2 sources where primary evidence is unavailable or insufficient, and label them. Tier 3 sources are supporting/context only. Tier 4 sources are withheld by the search tool.",
  BROAD:
    "Use Tier 1-3 sources to maximise coverage and label each source's tier. Tier 4 sources may appear: use them for discovery only, never as the basis of a material claim unless the consultant explicitly authorises it.",
};

/** What the webSearch tool returns when no level has been chosen yet. */
export function sourceTrustGateToolMessage(): string {
  return [
    "<web-results>",
    "SOURCE TRUST GATE: no source-trust level has been stated for this assignment, so web research has NOT been run.",
    "Do not search and do not answer from memory as if it were researched. Ask the consultant the question below, word for word, then STOP and wait for their choice:",
    "",
    SOURCE_TRUST_GATE_QUESTION,
    "</web-results>",
  ].join("\n");
}
