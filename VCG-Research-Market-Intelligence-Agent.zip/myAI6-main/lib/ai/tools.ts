import { type ToolSet } from "ai";
import { createWebSearch } from "@/app/api/chat/tools/web-search";
import { createFetchOwnerProfiles } from "@/app/api/chat/tools/fetch-owner-profiles";
import { createVectorDatabaseSearch } from "@/app/api/chat/tools/search-vector-database";
import {
  ENABLE_WEB_SEARCH,
  ENABLE_VECTOR_SEARCH,
  MAX_KB_SEARCHES,
  MAX_WEB_SEARCHES,
  OWNER_PROFILE_SOURCES,
} from "@/config";
import type { UISource } from "@/types/data";
import {
  SOURCE_POLICY_DESCRIPTION,
  SOURCE_TRUST_GATE_QUESTION,
  type SourceTrustLevel,
} from "@/lib/source-trust";

/** Collector callback: the source plus its retrieved text (for claim verification). */
export type CollectSource = (s: UISource, content?: string) => void;

/** Per-request state that changes what the agent may do. */
export interface ToolContext {
  /** Consultant's confirmed source-trust level, or null if not yet stated. */
  sourceTrust: SourceTrustLevel | null;
}

/**
 * Assembles the enabled tool set. `collect` is called by each tool for every
 * source it uses, feeding the code-rendered Sources box; the optional content
 * is the text the model saw, used to verify citation claims. Pass a no-op to
 * ignore sources. `ctx.sourceTrust` is enforced inside webSearch (the Source
 * Trust Gate), not just described in the prompt.
 */
export function buildToolSet(
  collect: CollectSource = () => {},
  ctx: ToolContext = { sourceTrust: null }
): ToolSet {
  return {
    ...(ENABLE_VECTOR_SEARCH ? { vectorDatabaseSearch: createVectorDatabaseSearch(collect) } : {}),
    ...(ENABLE_WEB_SEARCH
      ? {
          webSearch: createWebSearch(collect, { sourceTrust: ctx.sourceTrust }),
          // Only meaningful if the deployment configures profile pages to fetch.
          ...(OWNER_PROFILE_SOURCES.length > 0
            ? { fetchOwnerProfiles: createFetchOwnerProfiles(collect) }
            : {}),
        }
      : {}),
  };
}

function sourceTrustSection(level: SourceTrustLevel | null): string {
  if (!level) {
    return `SOURCE TRUST: NOT YET STATED for this assignment.
- This is the Source Trust Gate (master prompt s.6). If the consultant's brief does not specify STRICT, STANDARD or BROAD and the question needs research, ask this question word for word, then STOP and wait for the answer. Do not search and do not start the research.
- webSearch will refuse to run until a level has been stated, and returns the question below if you call it too early:

${SOURCE_TRUST_GATE_QUESTION}

- Questions that need no external research (for example "what can you do?") do not need the gate.`;
  }
  return `SOURCE TRUST: CONFIRMED BY THE CONSULTANT: ${level}
- ${SOURCE_POLICY_DESCRIPTION[level]}
- Do NOT ask the source-trust question again. Never change the level silently; it changes only if the consultant states a different one.
- If you must rely on a lower-tier source because stronger evidence is unavailable, say so explicitly next to the claim.`;
}

export function buildToolGuidance(ctx: ToolContext = { sourceTrust: null }): string {
  const sections: string[] = [sourceTrustSection(ctx.sourceTrust)];

  if (ENABLE_VECTOR_SEARCH) {
    sections.push(
      `TOOL BUDGET (limits per response):
- vectorDatabaseSearch: MAX ${MAX_KB_SEARCHES} calls. Searches VCG internal knowledge; anything returned is VCG INTERNAL EVIDENCE and must be labelled as such. Usually 1 call is enough; use a second only to reformulate after poor results. Check provenance and date, and do not carry client-confidential material across engagements.`
    );
    if (ENABLE_WEB_SEARCH) {
      sections.push(
        `- webSearch: MAX ${MAX_WEB_SEARCHES} calls. This is a research agent, so use it for the external evidence the research plan needs, not only to supplement internal results.
  a. Plan first, then search: one search path per research question (market structure, competitors, margins, drivers, and so on), not one generic query.
  b. Use additionalQueries for different angles, and run at least one search aimed at CONTRADICTING evidence before you synthesise (master prompt s.11, s.29).
  c. Prefer one call with 2-3 additionalQueries over several near-duplicate calls.
  d. Call it only once a source-trust level is confirmed.`
      );
    }
    sections.push(
      `- After receiving tool results, compose your answer. Do NOT search again for the same information.`
    );
  } else {
    sections.push(
      `NOTE: The VCG internal knowledge base is currently UNAVAILABLE. Do not claim to have checked VCG internal evidence; say that it was not consulted.`
    );
    if (ENABLE_WEB_SEARCH) {
      sections.push(
        `TOOL BUDGET (limits per response):
- webSearch: MAX ${MAX_WEB_SEARCHES} calls. One search path per research question, additionalQueries for different angles, and at least one search aimed at CONTRADICTING evidence before you synthesise. Call it only once a source-trust level is confirmed.`
      );
    }
  }

  if (ENABLE_WEB_SEARCH && OWNER_PROFILE_SOURCES.length > 0) {
    sections.push(
      `- fetchOwnerProfiles: MAX 1 call, only for questions about the configured profile pages.`
    );
  }

  sections.push(
    `CITATIONS:
- Cite inline as [[N]](url) using ONLY the exact source URLs from retrieved results. For internal sources without a URL, use the exact kb: target from their Source Citation field. NEVER fabricate or guess URLs.
- Citations are pure markers: every sentence must read completely with citations removed.
- Cite each fact to the source it ACTUALLY came from. Internal documents are dated snapshots: never cite them for facts newer than their date.
- Do NOT write a References or Sources section; the app renders a Sources box (with source tiers) from your inline citations.`
  );

  sections.push(
    `IMPORTANT:
- Model and vendor selection are controlled by the administrator backend.`
  );

  return sections.join("\n\n").trim();
}
