import { humanGateSubmissionSchema } from "@/lib/human-gate";

/**
 * Records an Engagement Manager's Human Gate decision (APPROVE / CHALLENGE /
 * REJECT) with its reason.
 *
 * Retention: the record is written as one structured JSON line to the server
 * log (event "human_gate_decision"), which a log drain can ship to a durable
 * store. This app has no database and no authentication, so:
 *   - the reviewer name is self-declared, not verified;
 *   - the endpoint is unauthenticated;
 *   - Vercel log retention is limited.
 * Replace the log line with a database write (and put the app behind SSO) before
 * relying on this as an audit trail. Reasons may mention client matters, so
 * treat the log sink as confidential.
 */
export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const parsed = humanGateSubmissionSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid decision data" },
      { status: 400 }
    );
  }

  const recordedAt = new Date().toISOString();
  const { messageId, conversationId, decision, reason, reviewer } = parsed.data;

  console.log(
    JSON.stringify({
      event: "human_gate_decision",
      recordedAt,
      messageId,
      conversationId: conversationId ?? null,
      decision,
      reason: reason?.trim() || null,
      reviewer: reviewer?.trim() || null,
    })
  );

  return Response.json({ success: true, recordedAt });
}
