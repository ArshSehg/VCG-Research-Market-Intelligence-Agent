import { tool } from 'ai';
import { z } from 'zod';
import Exa from 'exa-js';
import {
  EXA_NUM_RESULTS,
  EXA_SEARCH_TYPE,
  EXA_MAX_CHARACTERS,
  EXA_SYSTEM_PROMPT,
  EXA_LIVECRAWL,
} from '@/config';
import type { UISource } from '@/types/data';
import {
  applySourcePolicy,
  classifySource,
  SOURCE_POLICY_DESCRIPTION,
  sourceTrustGateToolMessage,
  tierLabel,
  type SourceTrustLevel,
  type TierAssessment,
} from '@/lib/source-trust';

// Lazy singleton: instantiating Exa at module load makes `next build` fail on
// machines without EXA_API_KEY (build-time page-data collection imports this
// module). The client is only created on first actual search.
let exaClient: Exa | null = null;
export function getExa(): Exa {
  if (!exaClient) exaClient = new Exa(process.env.EXA_API_KEY);
  return exaClient;
}

export function domainOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

export interface WebResult {
  title: string;
  url: string;
  source: string;
  content: string;
  publishedDate: string;
  /** Heuristic source tier; absent for tools that do not grade sources. */
  tier?: TierAssessment;
}

export interface FormatOptions {
  /** Source-trust level in force (adds the policy header). */
  level?: SourceTrustLevel;
  /** Results removed by policy; listed by domain only so they cannot be cited. */
  withheld?: WebResult[];
}

// Formats web results with the same citation scaffolding the knowledge base uses
// (see lib/sources.ts), so the model cites and links them inline the same way.
// Each source carries an explicit URL and a ready-to-use markdown link; the
// domain is kept distinct so facts are attributed to the exact site they came
// from. When a source has a tier, it is labelled as a domain-based heuristic so
// the model never presents it as a verification.
export function formatWebResults(
  results: WebResult[],
  synthesis: string,
  opts: FormatOptions = {}
): string {
  const header: string[] = [];
  if (opts.level) {
    header.push(`Source policy in force: ${opts.level}. ${SOURCE_POLICY_DESCRIPTION[opts.level]}`);
  }
  const withheld = opts.withheld ?? [];
  if (opts.level && withheld.length > 0) {
    const domains = [...new Set(withheld.map((w) => w.source || domainOf(w.url) || '(unknown)'))];
    header.push(
      `Withheld by ${opts.level} source policy (Tier 4, discovery only; do not cite or rely on these, and tell the consultant they were withheld): ${domains.join(', ')}`
    );
  }

  if (results.length === 0 && !synthesis) {
    const none =
      withheld.length > 0
        ? 'No results met the source policy. Say so, and consider a differently worded search for primary sources.'
        : 'No relevant web results found.';
    return `<web-results>\n${[...header, none].join('\n\n')}\n</web-results>`;
  }

  const blocks = results.map((r, i) => {
    const lines = [
      `# Web Source ${i + 1}`,
      `## Title`,
      r.title || '(untitled)',
      `## Site`,
      r.source || '(unknown)',
    ];
    if (r.tier) {
      lines.push(
        `## Source Tier (domain-based heuristic, not a verification)`,
        `${tierLabel(r.tier.tier)}${r.tier.classified ? '' : ' [unclassified]'}. Default use: ${r.tier.recommendedUse}. Basis: ${r.tier.reason}`
      );
    }
    lines.push(
      `## Reference Link (cite using this exact URL)`,
      `[${r.title || r.source || r.url}](${r.url})`,
      `## Published`,
      r.publishedDate || '(date unknown)',
      `## Excerpt`,
      r.content || '(no excerpt)'
    );
    return lines.join('\n');
  });

  if (synthesis) {
    blocks.push(
      `# Web Synthesis (overview only — no single URL; cite the individual Web Sources above for each claim)\n${synthesis}`
    );
  }

  return `<web-results>\n${[...header, ...blocks].join('\n\n')}\n</web-results>`;
}

export interface WebSearchOptions {
  /**
   * The consultant's confirmed source-trust level (master prompt s.6), or null
   * if none has been stated. With null the tool REFUSES to search and returns the
   * gate question instead, so the gate holds even if the model ignores the prompt.
   */
  sourceTrust: SourceTrustLevel | null;
}

/**
 * Builds the web search tool. `collect` receives a structured UISource for each
 * result used, so the code-rendered Sources box is populated independently of
 * the model's markdown. The tool still returns the scaffolded `<web-results>`
 * text to the model for citation.
 *
 * Source-trust enforcement (lib/source-trust.ts):
 *   - no level stated  -> no search; returns the Source Trust Gate question
 *   - STRICT / STANDARD -> explicit Tier 4 results withheld, rest ordered best tier first
 *   - BROAD            -> everything kept, each result labelled with its tier
 */
export function createWebSearch(
  collect: (s: UISource, content?: string) => void,
  { sourceTrust }: WebSearchOptions
) {
  return tool({
  description:
    'Search the web for external research evidence (market data, filings, regulation, competitors, benchmarks). ' +
    'Requires a confirmed source-trust level; if none has been stated the tool returns the Source Trust Gate question to put to the consultant instead of searching. ' +
    'Each result is labelled with a heuristic source tier (1 = primary ... 4 = discovery only) and a default recommended use. ' +
    'Write queries that target the evidence needed (for example "India cold chain market size 2024 NHB report"), and use additionalQueries to cover 2-3 different angles, including a query designed to find CONTRADICTING evidence. ' +
    'Use includeDomains only to restrict a search to specific authoritative sites the consultant or plan calls for (for example a regulator).',
  inputSchema: z.object({
    query: z.string().min(1).describe(
      'Primary search query targeting a specific piece of evidence (metric, entity, period, geography).'
    ),
    additionalQueries: z.array(z.string()).optional().describe(
      '2-3 alternative queries using DIFFERENT terminology or angles, including one aimed at contradicting or competing evidence.'
    ),
    includeDomains: z.array(z.string()).optional().describe(
      'Restrict results to these domains (e.g. ["sebi.gov.in","rbi.org.in"]). Use when the research plan calls for a specific authoritative source.'
    ),
  }),
  execute: async ({ query, additionalQueries, includeDomains }) => {
    // Source Trust Gate: no level, no research.
    if (!sourceTrust) return sourceTrustGateToolMessage();

    try {
      const response = await getExa().search(query, {
        type: EXA_SEARCH_TYPE,
        numResults: EXA_NUM_RESULTS,
        livecrawl: EXA_LIVECRAWL,
        ...(additionalQueries?.length ? { additionalQueries } : {}),
        ...(includeDomains?.length ? { includeDomains } : {}),
        systemPrompt: EXA_SYSTEM_PROMPT,
        contents: {
          text: { maxCharacters: EXA_MAX_CHARACTERS },
        },
      } as any); // cast needed: exa-js types lag behind API features

      const res = response as any;

      // A web source is only citable if it has a URL — drop the rest so the model
      // never surfaces an unlinkable web finding.
      const results: WebResult[] = (res.results || [])
        .filter((result: any) => result.url)
        .map((result: any) => ({
          title: result.title || '',
          url: result.url as string,
          source: domainOf(result.url),
          content: result.text?.slice(0, EXA_MAX_CHARACTERS) || '',
          publishedDate: result.publishedDate || '',
        }));

      // Deep search may return a synthesized overview (no single URL of its own)
      // plus grounding references. The grounding entries ARE citable sources —
      // without them a synthesis-heavy deep result leaves the model nothing to
      // cite. Merge them in, deduped against the regular results by URL.
      const synthesis = res.output?.content
        ? (typeof res.output.content === 'string'
            ? res.output.content
            : JSON.stringify(res.output.content))
        : '';

      const seenUrls = new Set(results.map((r) => r.url.toLowerCase().replace(/\/+$/, '')));
      for (const g of res.output?.grounding || []) {
        const gUrl: string = typeof g === 'string' ? g : g?.url || '';
        if (!gUrl) continue;
        const key = gUrl.toLowerCase().replace(/\/+$/, '');
        if (seenUrls.has(key)) continue;
        seenUrls.add(key);
        results.push({
          title: (typeof g === 'object' && (g?.title as string)) || domainOf(gUrl) || gUrl,
          url: gUrl,
          source: domainOf(gUrl),
          content: (typeof g === 'object' && (g?.text as string)?.slice(0, EXA_MAX_CHARACTERS)) || '',
          publishedDate: (typeof g === 'object' && (g?.publishedDate as string)) || '',
        });
      }

      // Grade, then apply the consultant's source policy.
      const graded = results.map((r) => ({ ...r, tier: classifySource(r.url) }));
      const { kept, withheld } = applySourcePolicy(graded, sourceTrust);

      for (const r of kept) {
        collect(
          {
            kind: 'web',
            title: r.title || r.source || r.url,
            url: r.url,
            site: r.source,
            ...(r.publishedDate ? { publishedDate: r.publishedDate } : {}),
            tier: r.tier.tier,
            tierClassified: r.tier.classified,
            recommendedUse: r.tier.recommendedUse,
          },
          `${r.title}\n${r.content}`
        );
      }

      // The synthesis is the search engine's own blend of ALL pages it read,
      // including any we just withheld. If anything was withheld, drop it so
      // withheld content cannot re-enter the answer through the back door.
      const safeSynthesis = withheld.length > 0 ? '' : synthesis;

      return formatWebResults(kept, safeSynthesis, { level: sourceTrust, withheld });
    } catch (error) {
      console.error('Error searching the web:', error);
      return '<web-results>\nWeb search is temporarily unavailable. Do NOT present this topic as researched from the web: tell the consultant the search failed, state what remains unverified, and do not fabricate URLs.\n</web-results>';
    }
  },
  });
}
