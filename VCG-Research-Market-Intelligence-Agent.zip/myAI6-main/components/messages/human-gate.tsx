"use client";

import { useState } from "react";
import { toast } from "sonner";
import { ShieldCheck, Check, MessageSquareWarning, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  formatDecisionMessage,
  MAX_REASON_CHARS,
  MIN_REASON_CHARS,
  type HumanGateDecision,
  type StoredHumanGateDecision,
} from "@/lib/human-gate";
import {
  loadHumanGateDecisions,
  saveHumanGateDecision,
  loadReviewerName,
  saveReviewerName,
} from "@/lib/storage";

const DECISION_LABEL: Record<HumanGateDecision, string> = {
  APPROVE: "Approved",
  CHALLENGE: "Challenged",
  REJECT: "Rejected",
};

/**
 * Human Gate controls (VCG master prompt section 24): shown under a research
 * pack that ends with the HUMAN GATE block. The Engagement Manager approves,
 * challenges or rejects; the decision and reason are retained (device storage +
 * server log) and, for CHALLENGE / REJECT, sent back to the agent as a message.
 *
 * Note: there is no sign-in in this app, so the reviewer name is self-declared.
 */
export function HumanGateControls({
  messageId,
  conversationId,
  disabled,
  onSendMessage,
}: {
  messageId: string;
  conversationId?: string;
  disabled?: boolean;
  onSendMessage?: (text: string) => void;
}) {
  const [stored, setStored] = useState<StoredHumanGateDecision | null>(() =>
    conversationId ? loadHumanGateDecisions(conversationId)[messageId] ?? null : null
  );
  const [choice, setChoice] = useState<HumanGateDecision | null>(null);
  const [reason, setReason] = useState("");
  const [reviewer, setReviewer] = useState(() => loadReviewerName());
  const [submitting, setSubmitting] = useState(false);

  const reasonRequired = choice === "CHALLENGE" || choice === "REJECT";
  const reasonOk = !reasonRequired || reason.trim().length >= MIN_REASON_CHARS;

  async function confirm() {
    if (!choice || !reasonOk || submitting) return;
    setSubmitting(true);

    const decidedAt = new Date().toISOString();
    const record: StoredHumanGateDecision = {
      decision: choice,
      ...(reason.trim() ? { reason: reason.trim() } : {}),
      ...(reviewer.trim() ? { reviewer: reviewer.trim() } : {}),
      decidedAt,
    };

    // Retain locally first, so the decision is never lost to a network error.
    if (conversationId) saveHumanGateDecision(conversationId, messageId, record);
    saveReviewerName(reviewer.trim());
    setStored(record);

    try {
      const res = await fetch("/api/human-gate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageId,
          conversationId,
          decision: choice,
          reason: record.reason,
          reviewer: record.reviewer,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
    } catch {
      toast.warning(
        "Decision saved on this device, but it could not be logged to the server."
      );
    }

    if (choice !== "APPROVE" && onSendMessage) {
      onSendMessage(formatDecisionMessage(choice, reason, reviewer));
    }
    setSubmitting(false);
    setChoice(null);
    setReason("");
  }

  // ---- Decided: show the retained decision ----
  if (stored) {
    const Icon = stored.decision === "APPROVE" ? Check : stored.decision === "CHALLENGE" ? MessageSquareWarning : X;
    return (
      <div className="mt-3 rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-sm">
        <div className="flex items-center gap-2 font-medium">
          <Icon className="size-4 shrink-0" />
          <span>
            Engagement Manager review: {DECISION_LABEL[stored.decision]}
          </span>
        </div>
        <div className="mt-1 text-xs text-muted-foreground">
          {stored.reviewer ? `${stored.reviewer} · ` : ""}
          {new Date(stored.decidedAt).toLocaleString()}
        </div>
        {stored.reason && (
          <p className="mt-1 whitespace-pre-wrap text-xs text-muted-foreground">
            Reason: {stored.reason}
          </p>
        )}
      </div>
    );
  }

  // ---- Pending ----
  return (
    <div className="mt-3 rounded-lg border border-border/60 bg-muted/30 px-3 py-2">
      <div className="mb-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
        <ShieldCheck className="size-4 shrink-0" />
        Engagement Manager review required before client-facing use
      </div>

      {!choice ? (
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" disabled={disabled} onClick={() => setChoice("APPROVE")}>
            Approve
          </Button>
          <Button size="sm" variant="outline" disabled={disabled} onClick={() => setChoice("CHALLENGE")}>
            Challenge
          </Button>
          <Button size="sm" variant="outline" disabled={disabled} onClick={() => setChoice("REJECT")}>
            Reject
          </Button>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          <div className="text-xs text-muted-foreground">
            {choice === "APPROVE" &&
              "Approve: the research can proceed to its intended use. Optional note:"}
            {choice === "CHALLENGE" &&
              "Challenge: say which evidence or analysis should be revisited. The agent will rework it."}
            {choice === "REJECT" &&
              "Reject: the research must not be used. Say why; the agent will restart the research path."}
          </div>
          <Textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            maxLength={MAX_REASON_CHARS}
            rows={3}
            placeholder={reasonRequired ? "Reason (required)" : "Note (optional)"}
            aria-label="Reason for decision"
          />
          <Input
            value={reviewer}
            onChange={(e) => setReviewer(e.target.value)}
            maxLength={120}
            placeholder="Reviewer name (optional, not verified)"
            aria-label="Reviewer name"
          />
          <div className="flex gap-2">
            <Button size="sm" disabled={!reasonOk || submitting} onClick={confirm}>
              Confirm {choice.toLowerCase()}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              disabled={submitting}
              onClick={() => {
                setChoice(null);
                setReason("");
              }}
            >
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
